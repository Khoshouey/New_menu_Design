﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.ShowInTaskbar = False
        Me.ControlBox = False
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Text = ""
        Me.FormBorderStyle = Windows.Forms.FormBorderStyle.None
        TransparencyKey = Color.White

        Me.BackColor = Color.White

        ' Me.Opacity = 0.5
        ' Me.PictureBox2.ContextMenuStrip = Me.ContextMenuStrip
    End Sub

    Private Sub PictureBox2_MouseHover(sender As Object, e As EventArgs) Handles PictureBox2.MouseHover
        Me.PictureBox2.Image = Image.FromFile(".\Images\File_2_Test.png")
    End Sub

    Private Sub PictureBox2_MouseLeave(sender As Object, e As EventArgs) Handles PictureBox2.MouseLeave
        Me.PictureBox2.Image = Image.FromFile(".\Images\File_1_Test.png")
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        Me.Close()
    End Sub

    Private Sub ToolStripMenuItem5_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem5.Click
        Me.Close()
    End Sub
End Class
